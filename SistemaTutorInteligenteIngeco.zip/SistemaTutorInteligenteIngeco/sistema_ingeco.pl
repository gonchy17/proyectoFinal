%VAUE

%CAUE

%AMORTIZACION
%sistema frances
%hechos
tiene(amortizacion,prestamo).
tiene(amortizacion,interes).
tiene(amortizacion,periodoAmortizacion).
%caso:tasa de renegociacion
tiene(amortizacion,tasaRenegociacion).

%reglas
correcto(X,Y):- tiene(X,A),tiene(X,B),tiene(X,Y).
%caso:tasa de renegociacion
correcto(X,Y):- tiene(X,A),tiene(X.B),tiene(X,C),tiene(X,Y).







