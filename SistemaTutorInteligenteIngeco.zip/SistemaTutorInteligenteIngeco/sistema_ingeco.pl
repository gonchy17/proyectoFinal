%VAUE
%1� conversion de tasas

%probando funcionalidad
suma(N,M,R):- R is N+M.
%CAUE
%1� conversion de tasas
%
%AMORTIZACION(Base de conocimientos)
%sistema frances

%1� conversion de tasas de cualquier tipo a tasas anuales

%2� calculo de la cuota


%3� calculo del interes

%I1=capital*interes
%capital(C1).
%interes(C2).

%regla
interesA(Capital,Interes,I):- I is Capital*Interes.


%4 calculo de amortizacion de capital
%Ak=cuota-i1
%cuota(5).
%interes(3).
%regla
%amork(Cuota,InteresA,Ak):-cuota(C1),interes(I1), Ak is C1-I1.
amork(Cuota,InteresA,Ak):- Ak is Cuota-InteresA.

%5� calculo de saldo a amortizar
% Sa=C-Ak
%capital(12).
%amorcapital(5).
%regla
% saldoAmor(Capital,Amortizacionk,Sa):-capital(C),amorcapital(Ak),Sa is
% C-Ak.
saldoAmor(Capital,Amortizacionk,Sa):- Sa is Capital-Amortizacionk.


%Ver si funciona.























