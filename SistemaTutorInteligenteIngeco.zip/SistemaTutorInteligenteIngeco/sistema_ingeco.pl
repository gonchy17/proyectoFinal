%VAUE
%1� conversion de tasas(investigar)

%probando VAUE1
vaue1(ValorVtas,Tasa,Anio,Saldo,V):- V is (-ValorVtas)*(Tasa*(1+Tasa)^Anio)/(((1+Tasa)^Anio)-1) + Saldo.
%probando vaue2
vaue2(ValorVtas,Tasa,Anio,SaldoIE1,SaldoIE2,V):- V is ((-ValorVtas)*(Tasa*(1+Tasa)^Anio)/(((1+Tasa)^Anio)-1)) +
(SaldoIE1/((1+Tasa)^(Anio-1)))*((Tasa*(1+Tasa)^Anio)/(((1+Tasa)^Anio)-1)) + SaldoIE2*(Tasa/(((1+0.10)^Anio)-1)).
%probando vaue3
vaue3(ValorVtas,Tasa,Anio,SaldoIE1,SaldoIE2,SaldoIE3,V):- V is ((-ValorVtas)+(SaldoIE1/((1+Tasa)^1))+(SaldoIE2/((1+Tasa)^2)))*((Tasa*(1+Tasa)^Anio)/(((1+Tasa)^Anio)-1))+SaldoIE3*(Tasa/(((1+Tasa)^Anio)-1)).

%CAUE
%1� conversion de tasas
%2� calculo del caue 1�iteracion
caueA(ValorV,Interes,Periodo,SaldoIE,C1):- C1 is ValorV*(Interes*(1+Interes)^Periodo)/(((1+Interes)^Periodo)-1)-SaldoIE.
%2� calculo del caue 2�iteracion
caue2(ValorV,Interes,Periodo,Egreso,SaldoIE,C2):- C2 is ((((ValorV)+(Egreso/((1+Interes)^Periodo-1)))*((Interes*(1+Interes)^Periodo)/(((1+Interes)^Periodo)-1)))) - (SaldoIE*(Interes*((1+Interes)^Periodo)/(((1+Interes)^Periodo)-1))).
%2� calculo del caue 3�iteracion
caue3(ValorV,Interes,Periodo,Egreso1,Egreso2,SaldoIE,C3):- C3 is (ValorV+(Egreso1/(1+Interes)+(Egreso2/(1+Interes)^2)))*((Interes*(1+Interes)^Periodo)/(((1+Interes)^Periodo)-1)) + SaldoIE*(Interes/(((1+Interes)^Periodo)-1)).

%AMORTIZACION(Base de conocimientos)

%sistema frances
%1� conversion de tasas de cualquier tipo a tasas anuales
%1.A� conversion de tasa efectiva mensual a cuatrimestral
tasaEfectivaX(Interes,HorizonteTiempo,PeriodoInteres,TEx):- TEx is ((1+Interes)^(HorizonteTiempo/PeriodoInteres))-1.

%1�1 caso: conversion de mensual a anual
interesMA(InteresM,IA):- IA is  InteresM*12.

% 1.2� caso: conversion de bimensual a anual
interesBA(InteresB,IA):- IA is InteresB*6.

% 1.3� caso: conversion de trimestral a anual
interesTA(InteresT,IA):- IA is InteresT*4.

% 1.4� caso: conversion de cuatrimestral a anual
interesCA(InteresC,IA):- IA is InteresC*3.

% 1.5� caso: conversion de trimestral a anual
interesSA(InteresS,IA):- IA is InteresS*2.

%casos especiales conversion de tasas.

%2� calculo de la cuota
cuota(Prestamo,Interes,Anio,C):- C is Prestamo*(Interes*(1+Interes)^Anio)/(((1+Interes)^Anio)-1).

%3� calculo del interes


%regla
interesA(Capital,Interes,I):- I is Capital*Interes.


%4� calculo de amortizacion de capital
%Ak=cuota-i1
%cuota(5).
%interes(3).
%regla
amork(Cuota,InteresA,Ak):- Ak is Cuota-InteresA.

%5� calculo de saldo a amortizar
% Sa=C-Ak
%capital(12).
%amorcapital(5).
%regla
% C-Ak.
saldoAmor(Capital,Amortizacionk,Sa):- Sa is Capital-Amortizacionk.


%Amortizacion con tasa de renegociacion
%1�
 cuotaReneg(Prestamo,Interes,EquivalenteEnAnios,C):- C is
 Prestamo*(Interes*(1+Interes)^EquivalenteEnAnios)/(((1+Interes)^EquivalenteEnAnios)-1).

% cuota(Prestamo,Interes,Anio,C):- C is
% Prestamo*(Interes*(1+Interes)^Anio)/(((1+Interes)^Anio)-1).


























