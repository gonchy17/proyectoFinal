/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clases;

import formularios.frmPrincipal;

/**
 *
 * @author G
 */
public class SistemaTutorInteligenteIngeco {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Ventana Principal
        frmPrincipal login=new frmPrincipal();
        //Centreamos la ventana principal
        login.setLocationRelativeTo(null);
        login.setVisible(true);
        
           
                 
       
    }
    
    
    
}
