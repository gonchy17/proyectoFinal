/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clases;

import javax.swing.ImageIcon;

/**
 *
 * @author G
 */
public class Tema {
    private int id_tema;
    private String cod_tema;
    private String formulas; //Blob por defecto  Ahora es solo la ruta de la imagen. 
    private String conceptos;
    private int id_usuario;

    public Tema() {
    }

    public Tema(int id_tema,String cod_tema, String formulas, String conceptos, int idUsuario) { //Blob por defecto.
        this.id_tema=id_tema;
        this.cod_tema = cod_tema;
        this.formulas = formulas;
        this.conceptos = conceptos;
        this.id_usuario = idUsuario;
    }

    public int getId_tema() {
        return id_tema;
    }

    public void setId_tema(int id_tema) {
        this.id_tema = id_tema;
    } 
    
    public String getCod_tema() {
        return cod_tema;
    }

    public void setCod_tema(String cod_tema) {
        this.cod_tema = cod_tema;
    }

    public String getFormulas() {  //blob
        return formulas;
    }

    public void setFormulas(String formulas) { //Blob
        this.formulas = formulas;
    }

    public String getConceptos() {
        return conceptos;
    }

    public void setConceptos(String conceptos) {
        this.conceptos = conceptos;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }
    
    
}
