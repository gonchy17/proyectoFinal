/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clases;

/**
 *
 * @author G
 */
public class Tema {
    private String cod_tema;
    private String formulas;
    private String conceptos;

    public Tema() {
    }

    public Tema(String cod_tema, String formulas, String conceptos) {
        this.cod_tema = cod_tema;
        this.formulas = formulas;
        this.conceptos = conceptos;
    }

    public String getCod_tema() {
        return cod_tema;
    }

    public void setCod_tema(String cod_tema) {
        this.cod_tema = cod_tema;
    }

    public String getFormulas() {
        return formulas;
    }

    public void setFormulas(String formulas) {
        this.formulas = formulas;
    }

    public String getConceptos() {
        return conceptos;
    }

    public void setConceptos(String conceptos) {
        this.conceptos = conceptos;
    }
    
    
}
