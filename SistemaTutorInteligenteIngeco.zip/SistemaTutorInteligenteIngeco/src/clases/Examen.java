/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clases;

/**
 *
 * @author G
 */
public class Examen {
    
    private String cod_examen;
    private String cod_tema; //Blob por defecto  Ahora es solo la ruta de la imagen.
    private int id_tema;
    private String pregunta; //Estos 2 ultimos longblob deberian ser string u otro dato que me permitan guardar las
    private String respuesta;//blob por defecto
    private int id_usuario;
    //private Blob[] Resoluciones;
    public Examen() {
    }

    public Examen(String cod_examen, String cod_tema,int id_tema ,String pregunta, String respuesta, int id_usuario) {//blob los 2 ultimos
        this.cod_examen = cod_examen;
        this.cod_tema = cod_tema;
        this.id_tema=id_tema;
        this.pregunta = pregunta;
        this.respuesta = respuesta;
        this.id_usuario = id_usuario; //agegado
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getId_tema() {
        return id_tema;
    }

    public void setId_tema(int id_tema) {
        this.id_tema = id_tema;
    }

    public String getCod_examen() {
        return cod_examen;
    }

    public void setCod_examen(String cod_examen) {
        this.cod_examen = cod_examen;
    }

    public String getCod_tema() {
        return cod_tema;
    }

    public void setCod_tema(String cod_tema) {
        this.cod_tema = cod_tema;
    }

    public String getPregunta() { //blob por defecto
        return pregunta;
    }

    public void setPregunta(String pregunta) { //blob por defecto
        this.pregunta = pregunta;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) { //estas son rutas para cargar los archivos a la base de datos.
        this.respuesta = respuesta;
    }
    
}
