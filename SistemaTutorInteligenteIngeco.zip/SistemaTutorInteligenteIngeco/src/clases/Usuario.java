/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clases;

/**
 *
 * @author Gonchy
 */
public class Usuario {
    //public  static int id_usuario;  //private por defecto. static nunca cambia.. ese debe ser el error.
    
    private int id_usuario;
    private String nombres;
    private String apellidos; 
    protected String rol;   
    
    //Metodo constructor.
    public Usuario() {
    }

    public Usuario(int id_usuario, String nombres, String apellidos, String rol) {
        //Usuario.id_usuario = id_usuario;  //corregir por defcto.
        this.id_usuario=id_usuario;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.rol = rol;        
        
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        //Usuario.id_usuario = id_usuario;   //Corregir por defecto.
        this.id_usuario=id_usuario;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombre) {
        this.nombres = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }
    
 }
