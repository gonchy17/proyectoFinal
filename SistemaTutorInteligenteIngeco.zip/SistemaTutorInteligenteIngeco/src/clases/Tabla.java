/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clases;

import conexion.ConexionDocente;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author G
 */
public class Tabla {
    private Tema tema;
    private Docente docente;
    private String sSQLTema;
    //private Conexion conexion = new Conexion();
    //private Connection cn= conexion.conexion();
    private String[] datosTema = new String[2];
    private ConexionDocente cnDoc;
    
    public void verTabla(JTable tabla){
        tabla.setDefaultRenderer(Object.class, new Render());
        JButton btnDescargar = new JButton("Descargar Material");
        btnDescargar.setName("m");
        JButton btnEliminarIns = new JButton("Eliminar");
        btnEliminarIns.setName("e");
        //Probando..xD
        cnDoc = new ConexionDocente();
        String[] materiaDoc; 
        materiaDoc = new String[2];  //2 por defecto.
        materiaDoc = cnDoc.mostrarDatosDocMat(); 
        DefaultTableModel d = new DefaultTableModel(  //Corregir lo de abajo.
        new Object[][]{{materiaDoc[0], materiaDoc[1],btnDescargar,btnEliminarIns},{"Vaue","Vaue" ,btnDescargar,btnEliminarIns},{"AMORTIZACION","gonchy",
            btnDescargar,btnEliminarIns}}, //Filas
        new Object[]{"Nombre del tema","Nombre del Docente","Descargas","Cancelar Descarga"}
        )
        {
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        tabla.setModel(d);
        tabla.setRowHeight(40);
         //completar mañana.       
       /* sSQLTema = "select t.cod_tema, d.id_usuario, d.nombres from tema t inner join docente d" // puede que falle esta parte.
                + " on t.id_usuario = d.id_usuario where d.tema_designado = 1" ; 
        String[] titulos = {"cod_tema","Nombre del docente","Inscripcion","Eliminar Inscripcion" };         
        DefaultTableModel d = new DefaultTableModel(null, titulos);
        try{
            Statement statement=cn.createStatement();     
            ResultSet rs = statement.executeQuery(sSQLTema);
            //PreparedStatement pstTema = cn.prepareStatement(sSQLTema);
            while(rs.next()){
                   datosTema[0] = rs.getString("cod_tema");           
                   datosTema[1] = rs.getString("nombres");
                   d.addRow(datosTema);
            }          
          }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
            //respuesta = false;
        } 
        /*DefaultTableModel d = new DefaultTableModel(
        new Object[][]{{"VAUE","Pedro",btnInscripcion,btnEliminarIns},{"CAUE","gonchy",btnInscripcion,btnEliminarIns},{"AMORTIZACION","gonchy",
            btnInscripcion,btnEliminarIns}}, //Filas
        new Object[]{"Nombre del tema","Nombre del Docente","Inscripcion","Eliminar Inscripcion"}
        )
        {
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        tabla.setModel(d);
        tabla.setRowHeight(30);
                */
    }
}
