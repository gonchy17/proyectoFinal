/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clases;

import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author G
 */
public class Tabla {
    
    public void verTabla(JTable tabla){
        tabla.setDefaultRenderer(Object.class, new Render());
        JButton btn1 = new JButton("Inscribirse");
        btn1.setName("m");
        JButton btn2 = new JButton("Eliminar");
        btn2.setName("e");     
                
        DefaultTableModel d = new DefaultTableModel(
        new Object[][]{{"1","Pedro",btn1,btn2},{"2","Juan",btn1,btn2},{"3","Rosa",btn1,btn2},{"4","Maria",btn1,btn2}}, //Filas
        new Object[]{"Codigo","Nombre","Inscripcion","Eliminar Inscripcion"}
        )
        {
            public boolean isCellEditable(int row, int column){
                return false;
            }
        };
        tabla.setModel(d);
        tabla.setRowHeight(30);
    }
}
