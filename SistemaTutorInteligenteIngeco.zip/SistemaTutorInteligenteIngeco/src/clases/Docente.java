/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clases;

/**
 *
 * @author Gonchy. 
 */
public class Docente extends Usuario{
    
    private String nombre_usDoc;
    private String passwd;
    
    //Metodo constructor.  
    public Docente() {
    }

    public Docente(String nombre_usDoc, String passw_doc) {
        
        this.nombre_usDoc = nombre_usDoc;
        this.passwd = passw_doc;
    }

    public String getNombre_usDoc() {
        return nombre_usDoc;
    }

    public void setNombre_usDoc(String nombre_usDoc) {
        this.nombre_usDoc = nombre_usDoc;
    }

    public String getPassw_doc() {
        return passwd;
    }

    public void setPassw_doc(String passw_doc) {
        this.passwd = passw_doc;
    }
   
}
