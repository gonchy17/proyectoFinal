/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package clases;

/**
 *
 * @author Gonchy. 
 */
public class Docente extends Usuario{
    private String rol;
    private String nombre_usDoc;
    private int passw_doc;
    
    //Metodo constructor.  
    public Docente() {
    }

    public Docente(String rol, String nombre_usDoc, int passw_doc) {
        this.rol=super.rol;
        this.nombre_usDoc = nombre_usDoc;
        this.passw_doc = passw_doc;
    }

    public String getNombre_usDoc() {
        return nombre_usDoc;
    }

    public void setNombre_usDoc(String nombre_usDoc) {
        this.nombre_usDoc = nombre_usDoc;
    }

    public int getPassw_doc() {
        return passw_doc;
    }

    public void setPassw_doc(int passw_doc) {
        this.passw_doc = passw_doc;
    }
        
}
