/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package formularios;

import CollectionJavaBeansDataSource.CostoAnualUniformeEquivalente;
import conexion.Conexion;
import java.io.File;
import java.sql.Connection;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import net.sf.clipsrules.jni.Environment;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.view.JasperViewer;
import org.jpl7.Query;



/**
 *
 * @author G
 */
public class formCAUE extends javax.swing.JFrame {

    private Environment clips;
    private String respuesta;
    
    //para los reportes
    private CostoAnualUniformeEquivalente caue;
    
    public formCAUE() {
        initComponents();
        //cargamos clips
        clips = new Environment();
        clips.load("posibleInterfaz.clp"); 
        //deshabilitamos ciertos controles por defecto.
        txtAño.setEnabled(false);
        txtCostosAnuales.setEnabled(false);
        txtVentas.setEnabled(false);
        txtTasaMinima.setEnabled(false);      
        btnDefinirRespuesta.setEnabled(false);
        //ocultamos algunos controles
        lblAnual.setVisible(false);
        
        //aca llenaria los años
        llenarAnios();
        //ocultar lblsRespuesta
        ocultarLbl();
        
        lblId_estudiante.setVisible(false);
        //ocultar botones
        btnCrearReporte.setVisible(false);
    }    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        btnCrearReporte = new javax.swing.JButton();
        btnDefinirRespuesta = new javax.swing.JButton();
        cbAño = new javax.swing.JCheckBox();
        cbVenta = new javax.swing.JCheckBox();
        cbCostos = new javax.swing.JCheckBox();
        cbTasa = new javax.swing.JCheckBox();
        btnAceptar = new java.awt.Button();
        lblRespuesta = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtTasaMinima = new javax.swing.JTextField();
        txtVentas = new javax.swing.JTextField();
        txtAño = new javax.swing.JTextField();
        txtCostosAnuales = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        cboTipoInteres = new javax.swing.JComboBox();
        jLabel14 = new javax.swing.JLabel();
        btnConvertir = new javax.swing.JButton();
        txtTasaConvertida = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel15 = new javax.swing.JLabel();
        lblAnual = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        pnpFlujos = new javax.swing.JPanel();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        lblValor1 = new javax.swing.JLabel();
        lblValor3 = new javax.swing.JLabel();
        jSeparator6 = new javax.swing.JSeparator();
        jSeparator7 = new javax.swing.JSeparator();
        lblValor5 = new javax.swing.JLabel();
        jSeparator8 = new javax.swing.JSeparator();
        jSeparator9 = new javax.swing.JSeparator();
        lblValor7 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        btnCancelar = new javax.swing.JButton();
        btnSalir = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaCAUE = new JTable(){

            public boolean isCellEditable(int rowIndex, int colIndex) {

                return true; //Las celdas no son editables.

            }
        };
        ;
        lblValor2 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtRes1 = new javax.swing.JTextField();
        lblValor4 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtRes2 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtRes3 = new javax.swing.JTextField();
        lblnombreUsEst = new javax.swing.JLabel();
        lblId_estudiante = new javax.swing.JLabel();
        lblResUno = new javax.swing.JLabel();
        lblResDos = new javax.swing.JLabel();
        lblResTres = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        lblValor6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel3.setBackground(new java.awt.Color(25, 77, 25));

        jPanel1.setBackground(new java.awt.Color(23, 69, 23));
        jPanel1.setForeground(new java.awt.Color(51, 153, 51));

        jPanel6.setBackground(new java.awt.Color(51, 153, 51));

        btnCrearReporte.setBackground(new java.awt.Color(25, 77, 25));
        btnCrearReporte.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnCrearReporte.setForeground(new java.awt.Color(255, 255, 255));
        btnCrearReporte.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Edit Property_20px.png"))); // NOI18N
        btnCrearReporte.setText("Crear Reporte");
        btnCrearReporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCrearReporteActionPerformed(evt);
            }
        });

        btnDefinirRespuesta.setBackground(new java.awt.Color(25, 77, 25));
        btnDefinirRespuesta.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnDefinirRespuesta.setForeground(new java.awt.Color(255, 255, 255));
        btnDefinirRespuesta.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Edit Property_20px.png"))); // NOI18N
        btnDefinirRespuesta.setText("Definir Respuesta");
        btnDefinirRespuesta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDefinirRespuestaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnDefinirRespuesta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnCrearReporte, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(48, Short.MAX_VALUE)
                .addComponent(btnDefinirRespuesta, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnCrearReporte, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54))
        );

        cbAño.setBackground(new java.awt.Color(51, 51, 51));
        cbAño.setForeground(new java.awt.Color(255, 255, 255));
        cbAño.setText("Año");

        cbVenta.setBackground(new java.awt.Color(51, 51, 51));
        cbVenta.setForeground(new java.awt.Color(255, 255, 255));
        cbVenta.setText("Valor Ventas");

        cbCostos.setBackground(new java.awt.Color(51, 51, 51));
        cbCostos.setForeground(new java.awt.Color(255, 255, 255));
        cbCostos.setText("Costos Anuales De Operacion");

        cbTasa.setBackground(new java.awt.Color(51, 51, 51));
        cbTasa.setForeground(new java.awt.Color(255, 255, 255));
        cbTasa.setText("Tasa Minima Atractividad");

        btnAceptar.setBackground(new java.awt.Color(85, 65, 118));
        btnAceptar.setFont(new java.awt.Font("Dialog", 0, 14)); // NOI18N
        btnAceptar.setForeground(new java.awt.Color(204, 204, 204));
        btnAceptar.setLabel("Aceptar");
        btnAceptar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAceptarActionPerformed(evt);
            }
        });

        lblRespuesta.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        lblRespuesta.setForeground(new java.awt.Color(255, 255, 255));
        lblRespuesta.setText("Recomendamos:");

        jLabel5.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Tasa Minima Atractividad:");

        jLabel6.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Valor Ventas:");

        jLabel13.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Periodo en Años:");

        txtVentas.setEnabled(false);

        txtAño.setEnabled(false);

        txtCostosAnuales.setEnabled(false);

        jLabel10.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Costos Anuales de Operacion:");

        cboTipoInteres.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Mensual", "Bimestral", "Trimestral", "Cuatrimestral", "Semestral" }));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("(En años)");

        btnConvertir.setBackground(new java.awt.Color(25, 77, 25));
        btnConvertir.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnConvertir.setForeground(new java.awt.Color(255, 255, 255));
        btnConvertir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Edit Property_20px.png"))); // NOI18N
        btnConvertir.setText("Convertir");
        btnConvertir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConvertirActionPerformed(evt);
            }
        });

        txtTasaConvertida.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txtTasaConvertida.setDisabledTextColor(new java.awt.Color(0, 0, 0));
        txtTasaConvertida.setEnabled(false);

        jLabel2.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("La tasa convertida es:");

        jSeparator2.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("(Ej:1,2..)");

        lblAnual.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        lblAnual.setForeground(new java.awt.Color(255, 255, 255));
        lblAnual.setText("Anual");

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 11)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 204));
        jLabel3.setText("2.- Realizar Calculos:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(120, 120, 120)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(cbAño)
                                .addGap(18, 18, 18)
                                .addComponent(cbVenta)
                                .addGap(18, 18, 18)
                                .addComponent(cbCostos)
                                .addGap(18, 18, 18)
                                .addComponent(cbTasa))
                            .addComponent(lblRespuesta, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(63, 63, 63)
                        .addComponent(btnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(20, 20, 20)
                                                .addComponent(jLabel15))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel10)
                                                .addGap(52, 52, 52)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(txtTasaMinima, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                    .addComponent(txtCostosAnuales, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addGap(335, 335, 335))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                            .addComponent(jLabel5)
                                                            .addComponent(jLabel13))
                                                        .addGap(69, 69, 69)
                                                        .addComponent(txtAño, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addGap(54, 54, 54)
                                                        .addComponent(jLabel14)))
                                                .addGap(35, 35, 35)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addComponent(cboTipoInteres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addGap(77, 77, 77)
                                                        .addComponent(btnConvertir, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                                        .addComponent(jLabel6)
                                                        .addGap(27, 27, 27)
                                                        .addComponent(txtVentas, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(382, 382, 382)
                                                .addComponent(jLabel2)
                                                .addGap(35, 35, 35)
                                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(lblAnual)
                                                    .addComponent(txtTasaConvertida, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                        .addGap(18, 18, 18)))
                                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cbVenta)
                            .addComponent(cbTasa)
                            .addComponent(cbAño)
                            .addComponent(cbCostos))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblRespuesta))
                    .addComponent(btnAceptar, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addComponent(jSeparator2)
                        .addGap(33, 33, 33))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel13)
                                    .addComponent(txtAño, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel6)
                                    .addComponent(txtVentas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(3, 3, 3)
                                .addComponent(jLabel15)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel10)
                                    .addComponent(txtCostosAnuales, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(16, 16, 16)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(txtTasaMinima, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cboTipoInteres, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btnConvertir, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel14)
                                .addGap(10, 10, 10)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(txtTasaConvertida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblAnual)))
                        .addContainerGap(36, Short.MAX_VALUE))))
        );

        jLabel1.setFont(new java.awt.Font("Rod", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 204, 204));
        jLabel1.setText("Equivalente");

        jLabel9.setFont(new java.awt.Font("Rod", 0, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(204, 204, 204));
        jLabel9.setText("Costo Anual Uniforme ");

        pnpFlujos.setBackground(new java.awt.Color(25, 77, 25));

        jSeparator1.setBackground(new java.awt.Color(204, 51, 0));
        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator4.setBackground(new java.awt.Color(0, 0, 204));
        jSeparator4.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator5.setBackground(new java.awt.Color(204, 51, 0));
        jSeparator5.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jLabel4.setFont(new java.awt.Font("Calibri", 0, 12)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setText("0                         1                           2                           3");

        lblValor1.setFont(new java.awt.Font("Calibri", 0, 11)); // NOI18N
        lblValor1.setForeground(new java.awt.Color(255, 255, 255));
        lblValor1.setText("val1");

        lblValor3.setFont(new java.awt.Font("Calibri", 0, 11)); // NOI18N
        lblValor3.setForeground(new java.awt.Color(255, 255, 255));
        lblValor3.setText("val3");

        jSeparator6.setBackground(new java.awt.Color(0, 0, 204));
        jSeparator6.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator7.setBackground(new java.awt.Color(204, 51, 0));
        jSeparator7.setOrientation(javax.swing.SwingConstants.VERTICAL);

        lblValor5.setFont(new java.awt.Font("Calibri", 0, 11)); // NOI18N
        lblValor5.setForeground(new java.awt.Color(255, 255, 255));
        lblValor5.setText("val5");

        jSeparator8.setBackground(new java.awt.Color(0, 0, 204));
        jSeparator8.setOrientation(javax.swing.SwingConstants.VERTICAL);

        jSeparator9.setBackground(new java.awt.Color(204, 51, 0));
        jSeparator9.setOrientation(javax.swing.SwingConstants.VERTICAL);

        lblValor7.setFont(new java.awt.Font("Calibri", 0, 11)); // NOI18N
        lblValor7.setForeground(new java.awt.Color(255, 255, 255));
        lblValor7.setText("val7");

        javax.swing.GroupLayout pnpFlujosLayout = new javax.swing.GroupLayout(pnpFlujos);
        pnpFlujos.setLayout(pnpFlujosLayout);
        pnpFlujosLayout.setHorizontalGroup(
            pnpFlujosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnpFlujosLayout.createSequentialGroup()
                .addGroup(pnpFlujosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnpFlujosLayout.createSequentialGroup()
                        .addGap(89, 89, 89)
                        .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(74, 74, 74)
                        .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnpFlujosLayout.createSequentialGroup()
                        .addGroup(pnpFlujosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblValor1)
                            .addGroup(pnpFlujosLayout.createSequentialGroup()
                                .addContainerGap()
                                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(59, 59, 59)
                        .addGroup(pnpFlujosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jSeparator5, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblValor3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(pnpFlujosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblValor5)
                            .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(67, 67, 67)
                        .addGroup(pnpFlujosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator9, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 12, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblValor7, javax.swing.GroupLayout.Alignment.TRAILING)))
                    .addGroup(pnpFlujosLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(pnpFlujosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnpFlujosLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(19, Short.MAX_VALUE)))
        );
        pnpFlujosLayout.setVerticalGroup(
            pnpFlujosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnpFlujosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnpFlujosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pnpFlujosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jSeparator9, javax.swing.GroupLayout.DEFAULT_SIZE, 32, Short.MAX_VALUE)
                    .addComponent(jSeparator7)
                    .addComponent(jSeparator1)
                    .addComponent(jSeparator5))
                .addGap(18, 18, 18)
                .addGroup(pnpFlujosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblValor1)
                    .addComponent(lblValor3)
                    .addComponent(lblValor5)
                    .addComponent(lblValor7))
                .addContainerGap(21, Short.MAX_VALUE))
            .addGroup(pnpFlujosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pnpFlujosLayout.createSequentialGroup()
                    .addGap(48, 48, 48)
                    .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 13, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(124, Short.MAX_VALUE)))
        );

        jPanel7.setBackground(new java.awt.Color(51, 153, 51));

        btnCancelar.setBackground(new java.awt.Color(0, 102, 204));
        btnCancelar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnCancelar.setForeground(new java.awt.Color(255, 255, 255));
        btnCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Delete_20px.png"))); // NOI18N
        btnCancelar.setText("Cancelar");
        btnCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancelarActionPerformed(evt);
            }
        });

        btnSalir.setBackground(new java.awt.Color(51, 51, 51));
        btnSalir.setForeground(new java.awt.Color(255, 255, 255));
        btnSalir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/Cancel_26px.png"))); // NOI18N
        btnSalir.setText("Terminar Tema");
        btnSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnSalir, javax.swing.GroupLayout.DEFAULT_SIZE, 147, Short.MAX_VALUE)
                    .addComponent(btnCancelar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(btnCancelar, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(btnSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tablaCAUE.setFont(new java.awt.Font("Segoe UI", 0, 12)); // NOI18N
        tablaCAUE.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Años", "Valor en Ventas", "Costos Anuales de Operacion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tablaCAUE.setGridColor(new java.awt.Color(204, 204, 255));
        tablaCAUE.setSelectionBackground(new java.awt.Color(62, 226, 141));
        tablaCAUE.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablaCAUEMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablaCAUE);
        if (tablaCAUE.getColumnModel().getColumnCount() > 0) {
            tablaCAUE.getColumnModel().getColumn(0).setPreferredWidth(50);
        }

        lblValor2.setFont(new java.awt.Font("Calibri", 0, 11)); // NOI18N
        lblValor2.setForeground(new java.awt.Color(255, 255, 255));
        lblValor2.setText("val2");

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Rod", 1, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(240, 240, 240));
        jLabel12.setText("Su problema tiene las siguientes datos?");

        jLabel8.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Respuesta 1º Iteracion:");

        txtRes1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txtRes1.setDisabledTextColor(new java.awt.Color(0, 0, 0));

        lblValor4.setFont(new java.awt.Font("Calibri", 0, 11)); // NOI18N
        lblValor4.setForeground(new java.awt.Color(255, 255, 255));
        lblValor4.setText("val4");

        jLabel11.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Respuesta 2º Iteracion:");

        txtRes2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txtRes2.setDisabledTextColor(new java.awt.Color(0, 0, 0));

        jLabel16.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Respuesta 3º Iteracion:");

        txtRes3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        txtRes3.setDisabledTextColor(new java.awt.Color(0, 0, 0));

        lblnombreUsEst.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        lblnombreUsEst.setForeground(new java.awt.Color(255, 255, 255));
        lblnombreUsEst.setText("nombreUsEst");

        lblId_estudiante.setFont(new java.awt.Font("Calibri", 0, 14)); // NOI18N
        lblId_estudiante.setForeground(new java.awt.Color(255, 255, 255));
        lblId_estudiante.setText("idUsEst");

        lblResUno.setFont(new java.awt.Font("Rod", 1, 12)); // NOI18N
        lblResUno.setForeground(new java.awt.Color(204, 204, 204));
        lblResUno.setText("Respuesta");

        lblResDos.setFont(new java.awt.Font("Rod", 1, 12)); // NOI18N
        lblResDos.setForeground(new java.awt.Color(204, 204, 204));
        lblResDos.setText("Respuesta");

        lblResTres.setFont(new java.awt.Font("Rod", 1, 12)); // NOI18N
        lblResTres.setForeground(new java.awt.Color(204, 204, 204));
        lblResTres.setText("Respuesta");

        jLabel17.setBackground(new java.awt.Color(255, 255, 255));
        jLabel17.setFont(new java.awt.Font("Arial Black", 0, 11)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(204, 204, 204));
        jLabel17.setText("1.- Seleccione las opciones:");

        lblValor6.setFont(new java.awt.Font("Calibri", 0, 11)); // NOI18N
        lblValor6.setForeground(new java.awt.Color(255, 255, 255));
        lblValor6.setText("val6");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 569, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel8)
                                .addGap(18, 18, 18)
                                .addComponent(txtRes1, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(18, 18, 18)
                                .addComponent(txtRes2, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addGap(18, 18, 18)
                                .addComponent(txtRes3, javax.swing.GroupLayout.PREFERRED_SIZE, 108, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(202, 202, 202)
                        .addComponent(jLabel12)
                        .addGap(140, 140, 140)
                        .addComponent(lblnombreUsEst, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(8, 8, 8)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblResUno)
                            .addComponent(lblResTres)
                            .addComponent(lblResDos)))
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(jPanel3Layout.createSequentialGroup()
                            .addGap(99, 99, 99)
                            .addComponent(lblValor2)
                            .addGap(65, 65, 65)
                            .addComponent(lblValor4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(lblValor6))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel3Layout.createSequentialGroup()
                            .addGap(18, 18, 18)
                            .addComponent(pnpFlujos, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(67, Short.MAX_VALUE))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(160, 160, 160)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel1)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(21, 21, 21))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(117, 117, 117)
                                .addComponent(lblId_estudiante)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel17)
                        .addGap(21, 942, Short.MAX_VALUE))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(33, 257, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblValor2)
                    .addComponent(lblValor4)
                    .addComponent(lblValor6))
                .addComponent(pnpFlujos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(258, 258, 258))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel1)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(lblId_estudiante)))
                        .addGap(25, 25, 25)
                        .addComponent(jLabel17)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jLabel12)
                                .addGap(18, 18, 18)
                                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(55, 55, 55)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(txtRes1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel8)
                                            .addComponent(lblResUno))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(txtRes2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel11)
                                            .addComponent(lblResDos))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                            .addComponent(txtRes3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel16)
                                            .addComponent(lblResTres)))
                                    .addGroup(jPanel3Layout.createSequentialGroup()
                                        .addGap(33, 33, 33)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(lblnombreUsEst))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(60, 60, 60)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAceptarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAceptarActionPerformed
        /*grupo = new ButtonGroup();   //Creamos el grupo para controlar la deseleccion de los rdbuttons.
        grupo.add(cbInteres);
        grupo.add(cbPrestamo);
        grupo.add(cbAño);
        grupo.add(cbTasaRenegociacion);
        */
        try{
            //clips.reset();  //comentado sabado 24-03.
            //1º ver si interes esta seleccionado
            if(cbAño.isSelected() && cbVenta.isSelected() && cbCostos.isSelected()
                && cbTasa.isSelected()){
                clips.eval("(assert (anios-valorVentas costosAnualesOperacion-tasaMinimaAtractividad))");
                //btnReiniciar.setVisible(true);
                clips.run();
                respuesta = clips.getInputBuffer();
                if(respuesta !=null){
                    lblRespuesta.setText("Recomendamos metodo sustitucion no identica usando CAUE");
                    //habilitar ciertos controles
                    txtTasaMinima.setEnabled(true);
                }
                //lblRespuesta.setText(respuesta);
                clips.reset();
                //Una vez hecho esto ver como capturamos el resultado de este consulta para imprimirlos a un jLabel.
                //Ver tambien como lo enviamos a prolog.
            }
            else{

                JOptionPane.showMessageDialog(null, "Debe marcar las 4 opciones, si ninguna de estas "
                            + "no son de su interes presione salir",
                    "Sistema Tutor Inteligente Ingeco",JOptionPane.YES_OPTION);

            }
            //clips.run();
            //String respuesta = clips.getInputBuffer();
            //lblRespuesta.setText(respuesta);
            //clips.destroy();
            // clips.reset();
        }
        catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
    }//GEN-LAST:event_btnAceptarActionPerformed

    private void btnSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSalirActionPerformed
        this.dispose();
        frmEstudiante est = new frmEstudiante();
        est.setVisible(true);
        
        frmEstudiante.lblnombreUsEst.setText(formCAUE.lblnombreUsEst.getText());
        frmEstudiante.lblId_estudiante.setText(formCAUE.lblId_estudiante.getText());
    }//GEN-LAST:event_btnSalirActionPerformed

    private void btnCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancelarActionPerformed
        //1º limpiar campos
        limpiarCampos();
    }//GEN-LAST:event_btnCancelarActionPerformed

    //la conexion
    private Connection connection=new Conexion().conexion();  //conexion es con minuscula en el video.
    
    private void btnCrearReporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCrearReporteActionPerformed
        Map p = new HashMap();
        JasperReport report; //aca falta importar las librerias jasperreport
        JasperPrint print;
        
        try {
            report=JasperCompileManager.compileReport(new File("").getAbsolutePath()+
                    "/src/Reportes/rpCAUE.jrxml"); //rpCAUE sera el nombre del reporte, tomar en cuenta esto.
            print=JasperFillManager.fillReport(report,p,connection);
            //Visulaizar el reporte
            JasperViewer view= new JasperViewer(print,false);
            view.setTitle("Reporte Del Examen Caue"); //investigar si se puede enviar el nombre del examen o no
            view.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnCrearReporteActionPerformed

    private void btnConvertirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConvertirActionPerformed
        //1º creamos la variable de la tasa de conversion 
        String tasaConvertida="";
        String res1="";
        String tasa=cboTipoInteres.getSelectedItem().toString();
        //2º conectar y convertir con prolog esta tasa, ver si usamos el metodo ddefinido en formAmort.
         try {
                String conexion = "consult('sistema_ingeco.pl')";  //colocar src
                Query con = new Query(conexion);
                //verificamos la conexion.
                boolean cnx = con.hasSolution();    
                //posiblemente usemos un for o while.
                if(cnx == true) {
                    System.out.println("conectado");                     
                    switch(tasa){//mensual //modificando c-12-09-18 
                        case "Mensual":
                        tasaConvertida="interesMA("+this.txtTasaMinima.getText()+",I)."; 
                        break; 
                        
                        case "Bimestral":
                        tasaConvertida="interesBA("+this.txtTasaMinima.getText()+",I)."; 
                        break;
                         
                        case "Trimestral":
                        tasaConvertida="interesTA("+this.txtTasaMinima.getText()+",I)."; 
                        break;
                            
                        case "Cuatrimestral":
                        tasaConvertida="interesCA("+this.txtTasaMinima.getText()+",I)."; 
                        break;
                            
                        case "Semestral":
                        tasaConvertida="interesSA("+this.txtTasaMinima.getText()+",I)."; 
                        break;
                            
                        default:
                            System.out.println("error");
                    }
                    //tasaConvertida="interesCA("+this.txtTasaMinima.getText()+",I)."; 
                    //esto corregir con su respectiva formula(lo de arriba)
                    Query c1 = new Query(tasaConvertida);
                    if(c1.hasSolution()){ 
                        res1 = (String.valueOf(c1.oneSolution().get("I").toString()));
                        //Probando aca la conversion a 4 dec
                        String valorCon=convertirCuatroDec(Float.parseFloat(res1)); //Double.parseDouble por defc.
                        txtTasaConvertida.setText(valorCon);
                        lblAnual.setVisible(true);
                        //y deshabilitamos ciertos control
                        txtTasaMinima.setEnabled(false);
                        cboTipoInteres.setEnabled(false);                                                     
                    }
                    else{
                        System.out.println("error");
                    }
                    int valorVta= Integer.parseInt(tablaCAUE.getValueAt(0,1).toString());//580000
                    int anio=Integer.parseInt(tablaCAUE.getValueAt(1, 0).toString());//1
                    int saldo= calcularSaldoIngEg(lblValor2.getText(),lblValor3.getText());
                    calcularCaue1(valorVta,res1,anio,saldo);//aparentemente funciona.
                    //ocultar, ver si es necesario ocultar todo para que no se vea feo.
                    lblValor2.setVisible(false);
                    jSeparator4.setVisible(false);
                    
                    //caue2                  
                    int anio2=Integer.parseInt(tablaCAUE.getValueAt(2,0).toString());
                    int eg1= Integer.parseInt(tablaCAUE.getValueAt(1, 2).toString());
                    int saldo1= calcularSaldoIngEgPos(lblValor4.getText(), lblValor5.getText());
                    System.out.println(saldo1);
                    calcularCaue2(valorVta,res1,anio2,eg1,saldo1);//corregir regla.
                    //ocultar
                    lblValor4.setVisible(false);
                    jSeparator6.setVisible(false);
                    
                    //caue3
                    int anio3=Integer.parseInt(tablaCAUE.getValueAt(3, 0).toString());//3
                    int eg11= Integer.parseInt(tablaCAUE.getValueAt(1, 2).toString());//10000
                    int eg12= Integer.parseInt(tablaCAUE.getValueAt(2, 2).toString());//16000
                    int saldo2=calcularSaldoIngEg(lblValor6.getText(), lblValor7.getText());//370000-24000
                    System.out.println(saldo2);
                    calcularCaue3(valorVta,res1,anio3,eg11,eg12,saldo2);
            }                                   
         }catch(Exception e){
                     e.printStackTrace();
         }
    }//GEN-LAST:event_btnConvertirActionPerformed

    private void btnDefinirRespuestaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDefinirRespuestaActionPerformed
        // 1º calcular la respuesta
        double caue1= Double.parseDouble(txtRes1.getText());
        double caue2= Double.parseDouble(txtRes2.getText());
        double caue3= Double.parseDouble(txtRes3.getText());
        
        String res;
        String anio;
        if(caue1 < caue2 && caue1 < caue3 ){
            anio="1";
            JOptionPane.showMessageDialog(null, "La respuesta es: " + caue1 + 
                    "y el periodo de vida util es "+anio+"",
                    "Sistema Tutor inteligente Ingeco",
                    JOptionPane.OK_OPTION);
                    lblResUno.setVisible(true);
                    System.out.println(caue1);
                    //res=Integer.toString(caue1);
                    
        }else{
            if(caue2 < caue1 && caue2 < caue3 ){
                anio="2";
                JOptionPane.showMessageDialog(null, "La respuesta es: " + caue2 +
                        "y el periodo de vida util es "+ anio+"",                        
                    "Sistema Tutor inteligente Ingeco",
                    JOptionPane.OK_OPTION);
                    lblResDos.setVisible(true);
                    System.out.println(caue2);
                    //res=Integer.toString(caue2);
                    
            }
            else{
                 if(caue3 < caue1 && caue3 < caue2 ){
                     anio="3";
                    JOptionPane.showMessageDialog(null, "La respuesta es: " + caue3+ " y el periodo de vida util es "
                        + ""+anio+"", //probar mañana
                    "Sistema Tutor inteligente Ingeco",
                    JOptionPane.OK_OPTION);
                    lblResTres.setVisible(true);
                    System.out.println(caue3);
                    //res=Integer.toString(caue3);                    
                 }
            }
        }        
        //2º capturamos la tsa convertida y la respuesta hallada
        /*String tasa= txtTasaConvertida.getText();
        caue = new CostoAnualUniformeEquivalente();
        caue.setRespuesta(res);
        caue.setTasaConvertida(tasa);
        caue.setAnio(anio);
        //3º una vez insettado el objeto creo que tengo que llamar al caueCollection para agregar
        //este onjeto.
        */
    }//GEN-LAST:event_btnDefinirRespuestaActionPerformed

    private void tablaCAUEMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablaCAUEMouseClicked
        //1º capturar los valores        
        int fSel=tablaCAUE.rowAtPoint(evt.getPoint());   //obtenemos filas y columnas
        int cSel= tablaCAUE.columnAtPoint(evt.getPoint());
        //asignamos valor a la grafica seleccionada, mejor la hago con un metodo.
        String saldo;
        //Todo este if ver si se puede mejorar, talves solo trabajar con la fila seleccionada.
        if(fSel==0 && cSel==1 && "0".equals(tablaCAUE.getValueAt(fSel, 0).toString())){ // Si es la 1º columna, insertamos el saldo
            saldo=tablaCAUE.getValueAt(fSel, cSel).toString(); //agrega pero muestra error al ejecutar.
            lblValor1.setText(saldo);
        } 
        //El otro valor a graficar       
        if(fSel==1 && "1".equals(tablaCAUE.getValueAt(fSel, 0).toString())){ //Ver si co9locanmos fila->1
            llenarValoresFilaUno(fSel,1); //1->cSel por defecto
        }                            
        //2º iteracion
        //graficar 2º iteracion
        if(fSel==2 && "2".equals(tablaCAUE.getValueAt(fSel, 0).toString())){ 
            llenarValoresFilaDos(fSel,1); //1->cSel por defecto.
        }   
        
        //3º iteracion
         if(fSel==3 && "3".equals(tablaCAUE.getValueAt(fSel, 0).toString())){ 
            llenarValoresFilaTres(fSel,1); //1->cSel por defecto.
        }
         //probando...
        if(fSel==4){
            JOptionPane.showMessageDialog(null, "No soportado!","Sistema Tutor Inteligente",
                    JOptionPane.INFORMATION_MESSAGE);
        }
        if(fSel==5){
            JOptionPane.showMessageDialog(null, "No soportado!","Sistema Tutor Inteligente",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_tablaCAUEMouseClicked
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(formVAUE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(formVAUE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(formVAUE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(formVAUE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new formVAUE().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private java.awt.Button btnAceptar;
    private javax.swing.JButton btnCancelar;
    private javax.swing.JButton btnConvertir;
    private javax.swing.JButton btnCrearReporte;
    private javax.swing.JButton btnDefinirRespuesta;
    private javax.swing.JButton btnSalir;
    private javax.swing.JCheckBox cbAño;
    private javax.swing.JCheckBox cbCostos;
    private javax.swing.JCheckBox cbTasa;
    private javax.swing.JCheckBox cbVenta;
    private javax.swing.JComboBox cboTipoInteres;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JSeparator jSeparator9;
    private javax.swing.JLabel lblAnual;
    public static javax.swing.JLabel lblId_estudiante;
    private javax.swing.JLabel lblResDos;
    private javax.swing.JLabel lblResTres;
    private javax.swing.JLabel lblResUno;
    private javax.swing.JLabel lblRespuesta;
    private javax.swing.JLabel lblValor1;
    private javax.swing.JLabel lblValor2;
    private javax.swing.JLabel lblValor3;
    private javax.swing.JLabel lblValor4;
    private javax.swing.JLabel lblValor5;
    private javax.swing.JLabel lblValor6;
    private javax.swing.JLabel lblValor7;
    public static javax.swing.JLabel lblnombreUsEst;
    private javax.swing.JPanel pnpFlujos;
    private javax.swing.JTable tablaCAUE;
    private javax.swing.JTextField txtAño;
    private javax.swing.JTextField txtCostosAnuales;
    private javax.swing.JTextField txtRes1;
    private javax.swing.JTextField txtRes2;
    private javax.swing.JTextField txtRes3;
    private javax.swing.JTextField txtTasaConvertida;
    private javax.swing.JTextField txtTasaMinima;
    private javax.swing.JTextField txtVentas;
    // End of variables declaration//GEN-END:variables

    private void limpiarCampos() {
        txtAño.setText("");
        txtVentas.setText("");
        txtCostosAnuales.setText("");
        txtTasaMinima.setText("");
        //borramos el valor de jtable caue, ojo, quizas no lo necesitemos.
        //tablaCAUE.setValueAt("",0,0);
        //codigo para borrar la tabla
        for (int i = 0; i < 6 ; i++) {  //esto es flas, Integer.parseInt(txtAño.getText()) por defecto.
            for (int j = 1; j <= 2; j++) { //esto es columnas
                tablaCAUE.setValueAt("", i, j);
            }
        }
    }
       

    private String convertirCuatroDec(double res) {
        String convertido;
        DecimalFormat df= new DecimalFormat("0.0000");
        convertido = df.format(res);
        return convertido;       
    }
    //Probando editar celdas, ver si se esta ejecutando.
    public boolean isCellEditable (int iRows, int iCols){ 
      return true; /// editable la tabla 
    } 

    private void llenarValoresFilaUno(int fSel, int cSel) {
        //1º declaramos las variables         
        String valorVentas;
        String costosAnuales;
        //Obtener los valores
        valorVentas=(tablaCAUE.getValueAt(fSel, cSel).toString());
        costosAnuales=(tablaCAUE.getValueAt(fSel, cSel+1).toString());        
        //asignar a sus labels
            lblValor2.setText(valorVentas);
            lblValor3.setText(costosAnuales);               
        
    }

    private boolean tresValores() {
        boolean res;
        res = lblValor1.getText()!= null && lblValor2.getText()!=null && lblValor3.getText()!=null;
        return res;
    }

    private int calcularSaldoIngEg(String ing, String eg) {
        int saldo;
        //capturar valores
        int ingreso=Integer.parseInt(ing);
        int egreso=Integer.parseInt(eg);
        saldo = ingreso-egreso;
        return saldo;
    }

    private void calcularCaue1(int valorVta, String interes, int anio,int saldo) {
        String res1;
        String caue1="caueA("+valorVta+","+interes+","+anio+","+saldo+",C1).";
        Query v1=new Query(caue1);                
                if(v1.hasSolution()){ 
                        res1 = (String.valueOf(v1.oneSolution().get("C1").toString()));
                        //Probando aca la conversion a 4 dec
                        String caue1Con=convertirCuatroDec(Double.parseDouble(res1));
                        System.out.println(caue1Con);  //sigue sin funcionar...XD que hare!
                        txtRes1.setText(caue1Con); 
                }
    }

    private void calcularCaue2(int valorVta,String interes,int anio, int eg,int saldoIE) {
        String res2;
        String caue2="caue2("+valorVta+","+interes+","+anio+","+eg+","+saldoIE+",C2).";
        Query v1=new Query(caue2);                
                if(v1.hasSolution()){ 
                        res2 = (String.valueOf(v1.oneSolution().get("C2").toString()));
                        //Probando aca la conversion a 4 dec
                        String caue2Con=convertirCuatroDec(Double.parseDouble(res2));
                        System.out.println(caue2Con);  //sigue sin funcionar...XD que hare!
                        txtRes2.setText(caue2Con); 
                }
    }

    private void calcularCaue3(int valorVta,String interes, int anio, int eg1,int eg2, int saldoIE) {
        String res3;
        String caue3="caue3("+valorVta+","+interes+","+anio+","+eg1+","+eg2+","+saldoIE+",C3).";
        Query v1=new Query(caue3);                
                if(v1.hasSolution()){ 
                        res3 = (String.valueOf(v1.oneSolution().get("C3").toString()));
                        //Probando aca la conversion a 4 dec
                        String caue3Con=convertirCuatroDec(Double.parseDouble(res3));
                        System.out.println(caue3Con);  //sigue sin funcionar...XD que hare!
                        txtRes3.setText(caue3Con); 
                        //uan vez calculado habilitar el boton cargarDatos c-24-07-18
                        btnDefinirRespuesta.setEnabled(true);
                }
    }    

    private void llenarValoresFilaDos(int fSel, int cSel) { //2,1
        String ingresos1;
        String ingresos2;
        String costosAnuales1;
        String costosAnuales2;
        //valores
        ingresos1=tablaCAUE.getValueAt(0, cSel).toString(); //580000
        ingresos2=tablaCAUE.getValueAt(fSel, cSel).toString();//440000
        costosAnuales1=tablaCAUE.getValueAt(fSel-1, cSel+1).toString();//10000
        costosAnuales2=tablaCAUE.getValueAt(fSel, cSel+1).toString();//16000
        //asugnar lbls
        lblValor1.setText(ingresos1);
        lblValor3.setText(costosAnuales1);
        lblValor4.setText(ingresos2);
        lblValor5.setText(costosAnuales2);
    }

    private int calcularSaldoIngEgPos(String ing, String eg) {
         int saldo;
        //capturar valores
        int ingreso=Integer.parseInt(ing);
        int egreso=Integer.parseInt(eg);
        saldo = ingreso+egreso;//probar mañana
        return saldo;
    }

    private void llenarValoresFilaTres(int fSel, int cSel) { //3,1
        String ingresos1;
        String ingresos2;
        String costosAnuales1;
        String costosAnuales2;   
        String costosAnuales3; 
        //valores
        ingresos1=tablaCAUE.getValueAt(0, cSel).toString(); //580000
        ingresos2=tablaCAUE.getValueAt(fSel, cSel).toString();//370000
        costosAnuales1=tablaCAUE.getValueAt(fSel-2, cSel+1).toString();//10000
        costosAnuales2=tablaCAUE.getValueAt(fSel-1, cSel+1).toString();//16000
        costosAnuales3=tablaCAUE.getValueAt(fSel, cSel+1).toString();//24000
        //lbls
        lblValor1.setText(ingresos1);
        lblValor3.setText(costosAnuales1);
        lblValor5.setText(costosAnuales2);
        lblValor6.setText(ingresos2);
        lblValor7.setText(costosAnuales3);
    }  

    private void llenarAnios() {         
        for(int i = 0; i < 6; i++){
            tablaCAUE.setValueAt(i, i, 0);
        }
        
    }  
    private void ocultarLbl() {
        this.lblResUno.setVisible(false);
        this.lblResDos.setVisible(false);
        this.lblResTres.setVisible(false);
    }
}
/*
    faltan 2 librerias para hacer los reportes, probar los desacrgados del video o seguir buscando,
    puede que no funcione bien si no trabjamos con todas las librerias...investigar
    * La columna años debe ser creada de manera automatica...impelementar esa funcionalidad. 
    Al presionar cancelar ver si es necesario ademas de limpiar los campos volver a habilitar el boton 
    "recomendar" de ambos formularios.Obviamente el boton recomendar deberia ser deshabilitado al momento
    de cumplir su mision.
*/