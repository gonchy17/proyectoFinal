/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package CollectionJavaBeansDataSource;

/**
 *
 * @author G
 */
public class Amortizacion {
    private String interesFinal;
    private String amortizacionFinal;
    private String cuotaFinal;
    //para amortizacion con tasarenegociacion
    private String nuevaCuota;

    //codigo del codExamen posiblemente
    public Amortizacion() {
    }

    public Amortizacion(String interesFinal, String amortizacionFinal, String cuotaFinal, String nuevaCuota) {
        this.interesFinal = interesFinal;
        this.amortizacionFinal = amortizacionFinal;
        this.cuotaFinal = cuotaFinal;
        //para amortizacion con tasarenegociacion
        this.nuevaCuota=nuevaCuota;
    }

    public String getInteresFinal() {
        return interesFinal;
    }

    public void setInteresFinal(String interesFinal) {
        this.interesFinal = interesFinal;
    }

    public String getAmortizacionFinal() {
        return amortizacionFinal;
    }

    public void setAmortizacionFinal(String amortizacionFinal) {
        this.amortizacionFinal = amortizacionFinal;
    }

    public String getCuotaFinal() {
        return cuotaFinal;
    }

    public void setCuotaFinal(String cuotaFinal) {
        this.cuotaFinal = cuotaFinal;
    }

    public String getNuevaCuota() {
        return nuevaCuota;
    }

    public void setNuevaCuota(String nuevaCuota) {
        this.nuevaCuota = nuevaCuota;
    }
    
}
