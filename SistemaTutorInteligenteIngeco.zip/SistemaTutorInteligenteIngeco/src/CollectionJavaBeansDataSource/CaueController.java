/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package CollectionJavaBeansDataSource;

import java.util.List;

/**
 *
 * @author G
 */
public class CaueController {
    private static CaueCollection caueCollection;
    
    //agregado por mi
    private static CostoAnualUniformeEquivalente caue;
    
    public static List<CostoAnualUniformeEquivalente> loadCaueCollection(){ //aparentemente no necesitamos esta clase..investigar
        fillCollection();//investigar si se puede enviar parametros.
        return caueCollection.getListCaue();
    }
    private static void fillCollection(){  //aca deberia enviar las respuestas.
        caue=new CostoAnualUniformeEquivalente();
        caueCollection = new CaueCollection();
        //asignaciones
        caue.getRespuesta();
        caue.getAnio();
        caue.getTasaConvertida();
        caueCollection.addAmortizacion(caue);
                //new CostoAnualUniformeEquivalente("1", "2", "0.1654") //estos datos son ficticios.
                               
        }
}
/*
    Mañana las librerias y probar conectividad.
*/