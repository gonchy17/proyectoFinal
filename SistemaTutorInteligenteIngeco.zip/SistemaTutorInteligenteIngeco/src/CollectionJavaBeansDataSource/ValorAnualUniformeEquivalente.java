/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package CollectionJavaBeansDataSource;

/**
 *
 * @author G
 */
public class ValorAnualUniformeEquivalente {
    
    private String respuesta;
    private String anio;
    private String tasaConvertida;
    //talves añadamos el nombre del equipo a depreciar y el codExamen

    public ValorAnualUniformeEquivalente() {
    }

    public ValorAnualUniformeEquivalente(String respuesta, String anio, String tasaConvertida) {
        this.respuesta = respuesta;
        this.anio = anio;
        this.tasaConvertida = tasaConvertida;
    }

    public String getRespuesta() {
        return respuesta;
    }

    public void setRespuesta(String respuesta) {
        this.respuesta = respuesta;
    }

    public String getAnio() {
        return anio;
    }

    public void setAnio(String anio) {
        this.anio = anio;
    }

    public String getTasaConvertida() {
        return tasaConvertida;
    }

    public void setTasaConvertida(String tasaConvertida) {
        this.tasaConvertida = tasaConvertida;
    }
    
    
}
/*
 Se deben crear los controller pero investigar bien ademas ver si se puede agregar mas controllers al jaspersoft
    investigar bien esa parte, todo en el vieo 17
*/