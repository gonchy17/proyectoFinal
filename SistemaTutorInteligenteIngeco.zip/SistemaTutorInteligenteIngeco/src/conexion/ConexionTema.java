/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conexion;

import clases.Tema;
import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author G
 */
public class ConexionTema {
    private Conexion conexion = new Conexion();
    private Connection cn= conexion.conexion();
    private String sSQLTema;
    private String sSQLExamen;
    private FileInputStream fis = null;
    public Integer totalRegistros;
    public ConexionTema(){
    }
    
    public boolean insertarTema(Tema tema) throws FileNotFoundException{
        boolean respuesta = false;
        sSQLTema = "insert into tema(cod_tema, formulas, conceptos, id_usuario)"+          
                //" values(?,?,?,(select id_usuario from usuario order by id_usuario asc limit 1))";  //te pille,aca esta el error.            
                   "values(?,?,?,?)";
        try{
            PreparedStatement pstTema = cn.prepareStatement(sSQLTema);                        
            //pstUsuario.setString(1, doc.getCodigoTema()); //estaba en este orden: 2,3,4,5
            File file = new File(tema.getFormulas());
            fis = new FileInputStream(file);
            pstTema.setString(1, tema.getCod_tema());           
            pstTema.setBinaryStream(2,fis,(int)file.length());      //Estaba en 1,2,3 por defecto.
            pstTema.setString(3, tema.getConceptos());      //Ver si modificamos a longblob. 
            
            //descomentado c-05-07-18
            pstTema.setInt(4, tema.getId_usuario());      //Ojo, ver si se lo puedde usar 
            ///Para saber si se añadio.
            int n = pstTema.executeUpdate();
            if(n != 0){                          
                respuesta = true;
            }
            else{
                return false;
            }
                       
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
            //respuesta = false;
        } 
        return respuesta;
    }
//Metodo mostrar Tema
    public DefaultTableModel mostrar(String nombreTema, String id_user) throws IOException{  
        DefaultTableModel modelo;
        String[] datosDoc = new String[5];//modificando desde aqui, ver si se puede modificar por like la where.
        String[] titulos= {"id_tema","cod_tema","formulas","conceptos","id_usuario"};
        totalRegistros = 0;
        
        modelo = new DefaultTableModel(null, titulos);
        //aca deberia modificar la consulta, solo un inner join mas y ver si es necesario enviar id_user.
        sSQLTema = "select t.id_tema, t.cod_tema, t.formulas, t.conceptos, d.id_usuario from tema t inner join docente d"
                + " on t.id_usuario = d.id_usuario where t.cod_tema like'%"+ nombreTema +"%'"
                + "and t.id_usuario='"+id_user+"'";//='" +nombreTema+ "'" ;por defecto.                  
               // + "";                              //like'%"+ nombreTema +"%'";       
                 //order by t.cod_tema";             
         try{
            Statement statement=cn.createStatement();            
            ResultSet rs = statement.executeQuery(sSQLTema);
            Blob imagen = null;
            while(rs.next()){
                datosDoc[0]= rs.getString("id_tema"); 
                datosDoc[1]= rs.getString("cod_tema"); 
                datosDoc[2]= rs.getString("formulas"); //Puede que de error aqui.                        
                datosDoc[3]= rs.getString("conceptos");         
                datosDoc[4]= rs.getString("id_usuario"); 
                totalRegistros = totalRegistros+1;
                modelo.addRow(datosDoc);                  
            }
            return modelo;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        return modelo;
    }
    //Actualizar datos del tema, posiblemente eliminemos esta actualizacion.
    public boolean editar(Tema t) throws FileNotFoundException{
        boolean respuesta = false;         
       
        sSQLTema = "update tema set formulas=?,conceptos=?"
                + "where cod_tema=?";             //where id_usuario=? por defecto.            
    
       try{
            PreparedStatement pstTema = cn.prepareStatement(sSQLTema);                        
            //pstUsuario.setString(1, doc.getCodigoTema()); //estaba en este orden: 2,3,4,5
            File file = new File(t.getFormulas());
            fis = new FileInputStream(file);
                       
            pstTema.setBinaryStream(1,fis,(int)file.length());      //Estaba en 2,3,4.
            pstTema.setString(2, t.getConceptos()); 
            pstTema.setString(3, t.getCod_tema());
            //Ver si modificamos a longblob.                                  
            //pstTema.setInt(4, tema.getId_usuario());    // ojo, ver si se lo puede editar.
            ///Para saber si se añadio.
            int n = pstTema.executeUpdate();
            if(n != 0){                          
                respuesta = true;
            }
            else{
                return false;
            }
                       
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
            //respuesta = false;
        } 
        return respuesta;  
                                   
    }

    public boolean eliminar(Tema tema) {
         boolean res=false; // no se elimino por defecto
         //probar mañana, ver si es necesario usar el eliminar examen.         
        sSQLExamen="delete from examen where id_tema=?";
        sSQLTema="delete from tema where id_tema=?";
        try {            
            PreparedStatement pstTema = cn.prepareStatement(sSQLTema); 
            PreparedStatement pstExamen = cn.prepareStatement(sSQLExamen);
            pstTema.setInt(1, tema.getId_tema());                     
            pstExamen.setInt(1, tema.getId_tema());
            
            int n = pstTema.executeUpdate(); 
            int m = pstExamen.executeUpdate(); 
            if(n != 0 && m==0){                          
                                   
               //JOptionPane.showMessageDialog(null, "Se eliminaron los registros",
               //        "Sistema Tutor Inteligente Ingeco",JOptionPane.INFORMATION_MESSAGE);
                res=true;
            }
            else{
                    JOptionPane.showMessageDialog(null, "No se eliminaron los examenes, "
                            + "Posiblemente este tema no tenga examenes");
                    
            }
        }catch(SQLException e){
         JOptionPane.showMessageDialog(null, e);
        }
         return res;
    }
}
