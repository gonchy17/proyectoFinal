/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conexion;

import clases.Tema;
import java.io.File;
import java.io.FileInputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author G
 */
public class ConexionTema {
    private Conexion conexion = new Conexion();
    private Connection cn= conexion.conexion();
    private String sSQLTema;
    public ConexionTema(){
    }
    
    public boolean insertarTema(Tema tema){
        boolean respuesta = false;
        sSQLTema = "insert into tema(cod_tema, formulas, conceptos, id_usuario)" + 
                " values(?,?)";                
              
        try{
            PreparedStatement pstTema = cn.prepareStatement(sSQLTema);
                        
            //pstUsuario.setString(1, doc.getCodigoTema()); //estaba en este orden: 2,3,4,5
            pstTema.setString(1, tema.getCod_tema());           
            pstTema.setBlob(2,(Blob)tema.getFormulas());      //Estaba en 2,3,4.
            pstTema.setString(3, tema.getConceptos());      //Ver si modificamos a longblob.                                  
            pstTema.setInt(4, tema.getId_usuario());
            ///Para saber si se añadio.
            int n = pstTema.executeUpdate();
            if(n != 0){                          
                respuesta = true;
            }
            else{
                return false;
            }
                       
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
            //respuesta = false;
        } 
        return respuesta;
    }

    
}
