/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Gonzalo
 */
public class Conexion {
    
    Connection conect= null;
    
    public Conexion(){
    }
    public Connection conexion(){
        try{
            //Cargamos el driver MYSQL.
           // Class.forName("com.mysql.jdbc.Driver");
            
            //Esta version de base de ddatos sistema ingeco 3 no tiene update on cascade.
            Class.forName("org.gjt.mm.mysql.Driver");
            conect= DriverManager.getConnection("jdbc:mysql://localhost/sistemaingeco5","root",""); 
        }
        catch(ClassNotFoundException | SQLException e){
            //Mostramos un mensaje de error en caso de que no haya conexion. 
            JOptionPane.showMessageDialog(null,"Error al conectar con la base de datos"+e);
        }
        return conect;
        
    }
}
