/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conexion;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Gonchy.
 */
public class ConexionUsuario {
    Conexion conexion;
    Connection cn= conexion.conexion();

    public ConexionUsuario() {
        conexion = new Conexion();
    }
    //Metodo insertar usuario (Crud usuario).Equivalente a registrar para nuestro caso.
    public boolean insertarUsuario(String nombre, String apellidos, String rol){
        boolean respuesta = false;    //Asumimos que no hay ningun campo registrado.
        try{
            Connection acceso = conexion.conexion();
            CallableStatement cs = acceso.prepareCall("(call sp_insertUsuario(?,?,?,?)");
            cs.setString(1, nombre);
            cs.setString(2, apellidos);
            cs.setString(3, rol);
           
            
            int numFilasAfectadas=cs.executeUpdate();
            if(numFilasAfectadas>0){
                respuesta = true;
            }
        }catch(SQLException e){
        
        } 
        return respuesta;
    }
    //Metodo leer datos  del usuario (Crud Usuario).
    public ArrayList<Usuario>listaUsuario(){
        ArrayList<Usuario> usuarios = new ArrayList<Usuario>();
        Usuario usuario;
        try{
            Connection acceso = conexion.conexion();
            PreparedStatement ps = acceso.prepareStatement("Select * from usuario");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                usuario = new Usuario();
                usuario.setNombre(rs.getString(1));
                usuario.setApellidos(rs.getString(2));
                usuario.setRol(rs.getString(3));                             
                usuarios.add(usuario);                           
            }
        }catch(SQLException e){
        }
        return usuarios;
    }
}
