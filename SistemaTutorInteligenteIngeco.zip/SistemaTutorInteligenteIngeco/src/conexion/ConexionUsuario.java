/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conexion;

import clases.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author G
 */
public class ConexionUsuario {
    private Conexion conexion = new Conexion();
    private Connection cn= conexion.conexion();
    private String sSQLUsuario;
    //por si acaso
    public int totalRegistros;

    public ConexionUsuario() {
    }   
    
    public boolean eliminar(Usuario u){
        boolean res=false;  //por defecto asumimos que no se elimino el estudiante.
        sSQLUsuario="delete from usuario where id_usuario=?";
        try {            
            PreparedStatement pstUsuario = cn.prepareStatement(sSQLUsuario);        
            pstUsuario.setInt(1, u.getId_usuario());   //ver si esto provoca errores por usar a usuario en vez de est.        
            int n = pstUsuario.executeUpdate(); 
            if(n != 0){                                           
                    res=true;
                    //llamar a usuario para eliminar...ver videos por si acaso.
            }
            else{
                    JOptionPane.showMessageDialog(null, "No se elimino al usuario");
                    
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        return res;
    
    }
    
}
/*
    No usamos esta clase para nada... eliminar si es necesario
*/