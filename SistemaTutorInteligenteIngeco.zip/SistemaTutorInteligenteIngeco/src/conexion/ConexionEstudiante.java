/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conexion;

import clases.Estudiante;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.apache.commons.codec.digest.DigestUtils;

/**
 *
 * @author Gonchy.
 */
public class ConexionEstudiante {
    private Conexion conexion = new Conexion();
    private Connection cn= conexion.conexion();
    private String sSQLEstudiante;
    private String sSQLUsuario;
    public int totalRegistros;
    
    
    
    public ConexionEstudiante(){
    
    }
    //Metodo mostrar.
    public DefaultTableModel mostrar(String buscar){  
        DefaultTableModel modelo;
        String []registro= new String[6];
        String[] titulos= {"id_usuario","nombre","apellidos","rol","nombre_usEst","passwd"};//no se muestra el estado
        // y el porc_avance, talves no mostremos el campo rol.
        modelo = new DefaultTableModel(null, titulos);
        totalRegistros=0;               
        
        sSQLEstudiante="select u.id_usuario, u.nombres, u.apellidos, u.rol, e.nombre_usEst, e.passwd from usuario u inner join estudiante e"
                +" on u.id_usuario = e.id_usuario where nombre_usEst like '"+ buscar +"'" ;  
        //aca la consulta del tema.
        try{
            Statement statement=cn.createStatement();
            ResultSet rs = statement.executeQuery(sSQLEstudiante);
            while(rs.next()){
                registro[0]=rs.getString("id_usuario");
                registro[1]=rs.getString("nombres");
                registro[2]=rs.getString("apellidos");
                registro[3]=rs.getString("rol");
                registro[4]=rs.getString("nombre_usEst"); 
                registro[5]=rs.getString("passwd");
                //registro[6]=rs.getString("porc_avance"); //ojo con esto
                              
                totalRegistros=totalRegistros+1;
                modelo.addRow(registro);
            }
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return modelo;
    }
    //Metodo insertar usuario (Crud usuario).Equivalente a registrar para nuestro caso.
    public boolean insertarEstudiante(Estudiante es){
        boolean respuesta = false;
        sSQLUsuario = "insert into usuario(nombres, apellidos,rol)" + 
                " values(?,?,?)";                
       
        sSQLEstudiante = "insert into estudiante(id_usuario, nombre_usEst, passwd, porc_avance, estado)" 
               + "values((select id_usuario from usuario order by id_usuario desc limit 1),?,?,?,?)";
                //+ "values((select id_usuario from usuario order by id_usuario desc limit 1),?,?)";
        try{
            PreparedStatement pstUsuario = cn.prepareStatement(sSQLUsuario);
            PreparedStatement pstEstudiante = cn.prepareStatement(sSQLEstudiante);
            
            //pstUsuario.setString(1, doc.getCodigoTema()); //estaba en este orden: 2,3,4,5
            pstUsuario.setString(1, es.getNombres());      //Estaba en 2,3,4.
            pstUsuario.setString(2, es.getApellidos());
            pstUsuario.setString(3, es.getRol());
                         
            pstEstudiante.setString(1, es.getNombre_usEst());
            //Primero encriptamos el password y luego lo ingresamos a la base de datos.
            //String passwdEncriptado = DigestUtils.md5Hex(es.getPassw_est());                      
            pstEstudiante.setString(2,es.getPassw_est());
            pstEstudiante.setInt(3, es.getPorc_avance());   // Comprobar mañana esta instruccion, ver el orden de los parametros.
            pstEstudiante.setInt(4, es.getEstado());
            ///Para saber si se añadio.
            int n = pstUsuario.executeUpdate();
            if(n != 0){                          
                    int p = pstEstudiante.executeUpdate();
                    return p!=0;  
            }
            else{
                respuesta = false;
            }
                       
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
            //respuesta = false;
        } 
        return respuesta;
    }
    
     public boolean actualizarDatosEst(Estudiante es){
         boolean respuesta = false;
         
        int idUsuarioEst = es.getId_usuario();
        sSQLUsuario = "update usuario set nombres=?,apellidos=?"
                + "where id_usuario=?";             //where id_usuario=? por defecto.            
    
        //  "Select id_usuario from docente where (nombre_usdoc = '"+ nombreUsDoc+"')";
        
        sSQLEstudiante = "update estudiante set nombre_usEst=?,passwd=?"
                +"where id_usuario=?";              //where id_usuario=? por defecto.
        try {
            PreparedStatement pstUsuario = cn.prepareStatement(sSQLUsuario);
            PreparedStatement pstEstudiante = cn.prepareStatement(sSQLEstudiante);
            
            pstUsuario.setString(1, es.getNombres());      
            pstUsuario.setString(2, es.getApellidos());
            pstUsuario.setInt(3,idUsuarioEst); 
            
            pstEstudiante.setString(1, es.getNombre_usEst());
            pstEstudiante.setString(2,es.getPassw_est());
            pstEstudiante.setInt(3,idUsuarioEst);
            
            int n = pstUsuario.executeUpdate();
            if(n != 0){                          
                    int p = pstEstudiante.executeUpdate();
                return p!=0;  
            }
            else{
                return false;
            }
        }catch(SQLException e){
         JOptionPane.showMessageDialog(null, e);
        }
        return respuesta; 
     }
     //crud eliminar
     public boolean eliminar(Estudiante est){
        boolean res=false;  //por defecto asumimos que no se elimino el estudiante.
        sSQLEstudiante="delete from estudiante where id_usuario=?";
        sSQLUsuario="delete from usuario where id_usuario=?";
        try {            
            PreparedStatement pstEstudiante = cn.prepareStatement(sSQLEstudiante); 
            PreparedStatement pstUsuario = cn.prepareStatement(sSQLUsuario);
            
            pstEstudiante.setInt(1, est.getId_usuario());           
            pstUsuario.setInt(1, est.getId_usuario());
            //En el video elimina todos los datos campos de la entidad 2, en este caso estudiante...investigar.
            int n = pstEstudiante.executeUpdate(); 
            int m = pstUsuario.executeUpdate(); 
            if(n != 0 && m!=0){  
                
                    //JOptionPane.showMessageDialog(null, "Se elimino al estudiante");                   
                    res=true;                                                                         
            }
            else{
                    JOptionPane.showMessageDialog(null, "No se elimino al estudiante");
                    
            }
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        return res;   
    }
     
}

/*
    ver el video 9 para verificar este ejemplo, aparentemente funciona todo bien los cruds.
*/