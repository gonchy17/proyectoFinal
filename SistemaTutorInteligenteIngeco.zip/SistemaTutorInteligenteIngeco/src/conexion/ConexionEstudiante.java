/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conexion;

import clases.Estudiante;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import org.apache.commons.codec.digest.DigestUtils;

/**
 *
 * @author Gonchy.
 */
public class ConexionEstudiante {
    private Conexion conexion;
    private Connection cn= conexion.conexion();
    private String sSQLEstudiante;
    private String sSQLUsuario;
    
    public ConexionEstudiante(){
    
    }
    
    //Metodo insertar usuario (Crud usuario).Equivalente a registrar para nuestro caso.
    public boolean insertarEstudiante(Estudiante es){
        boolean respuesta = false;
        sSQLUsuario = "insert into usuario(nombres, apellidos,rol)" + 
                " values(?,?,?)";                
       
        sSQLEstudiante = "insert into estudiante(id_usuario,nombre_usEst,passwd)" 
               + "values((select id_usuario from usuario order by id_usuario desc limit 1),?,?)";
                //+ "values((select id_usuario from usuario order by id_usuario desc limit 1),?,?)";
        try{
            PreparedStatement pstUsuario = cn.prepareStatement(sSQLUsuario);
            PreparedStatement pstEstudiante = cn.prepareStatement(sSQLEstudiante);
            
            //pstUsuario.setString(1, doc.getCodigoTema()); //estaba en este orden: 2,3,4,5
            pstUsuario.setString(1, es.getNombres());      //Estaba en 2,3,4.
            pstUsuario.setString(2, es.getApellidos());
            pstUsuario.setString(3, es.getRol());
                         
            pstEstudiante.setString(1, es.getNombre_usEst());
            //Primero encriptamos el password y luego lo ingresamos a la base de datos.
            String passwdEncriptado = DigestUtils.md5Hex(es.getPassw_est());                      
            pstEstudiante.setString(2,passwdEncriptado);
            ///Para saber si se añadio.
            int n = pstUsuario.executeUpdate();
            if(n != 0){                          
                    int p = pstEstudiante.executeUpdate();
                    return p!=0;  
            }
            else{
                respuesta = false;
            }
                       
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
            //respuesta = false;
        } 
        return respuesta;
    }
}
