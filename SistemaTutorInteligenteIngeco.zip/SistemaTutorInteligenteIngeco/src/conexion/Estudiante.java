/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conexion;

/**
 *
 * @author G
 */
public class Estudiante {
    private String rol;
    private String nombre_usEst;
    private int porc_avance;
    private int passw_est;
//Metodo constructor.
public Estudiante() {      //Ver si usamos este constructor o usamos uno vacio.
        this.rol = "";
        nombre_usEst="";
        porc_avance=0;
    }

    public String getRol() {
        return rol;
    }
    public String getNombre_usEst() {
        return nombre_usEst;
    }

    public void setNombre_usEst(String nombre_usEst) {
        this.nombre_usEst = nombre_usEst;
    }

    public int getPorc_avance() {
        return porc_avance;
    }

    public void setPorc_avance(int porc_avance) {
        this.porc_avance = porc_avance;
    }

    public int getPassw_est() {
        return passw_est;
    }

    public void setPassw_est(int passw_est) {
        this.passw_est = passw_est;
    }
  
}
