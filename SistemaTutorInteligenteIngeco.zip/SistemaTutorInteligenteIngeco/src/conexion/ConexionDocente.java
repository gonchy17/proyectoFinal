/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conexion;

import clases.Docente;
import clases.Tema;
import clases.Usuario;
import static formularios.frmEstudiante.lblnombreUsEst;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import org.apache.commons.codec.digest.DigestUtils;

/**
 *
 * @author Gonchy.
 */
public class ConexionDocente {
    
    private final Conexion conexion = new Conexion();;
    private final Connection cn= conexion.conexion();
    private String sSQLDocente;
    private String sSQLUsuario;
    private String sSQLTema;
    public Integer totalRegistros;
    private String sSQLMatDoc;
   // private Statement statement;
   // private ResultSet resDoc;
    
    public ConexionUsuario usuario; 
    public Usuario us;
    
    public ConexionDocente(){
    
    }
   //Metodo mostrar usuario docente, metodo pendiente para el update docente.
    public DefaultTableModel mostrar(String nombreUsuario){  
        DefaultTableModel modelo;
        String[] datosDoc=new String[5];  //,modificado en fecha 29-06-18       
        String[] titulos= {"id_usuario","nombre","apellidos","nombre_usDoc","passwd"};
        totalRegistros = 0;
        modelo = new DefaultTableModel(null, titulos);
        sSQLDocente="select u.id_usuario, u.nombres, u.apellidos, d.nombre_usDoc, d.passwd from usuario u inner join docente d"
                +" on u.id_usuario = d.id_usuario where nombre_usDoc like '"+ nombreUsuario +"'" ;             
                //+"";    //'"+ nombreUsuario +"'";    
                 //order by id_usuario desc";              
        
        try{
            Statement statement=cn.createStatement();            
            ResultSet rs = statement.executeQuery(sSQLDocente);
            while(rs.next()){
                datosDoc[0]=rs.getString("id_usuario");
                datosDoc[1]=rs.getString("nombres");
                datosDoc[2]=rs.getString("apellidos");                
                datosDoc[3]=rs.getString("nombre_usDoc");         
                datosDoc[4]=rs.getString("passwd"); 
                totalRegistros = totalRegistros+1;
                modelo.addRow(datosDoc);                  
            }
            return modelo;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        return modelo;
    }
    //Metodo insertar usuario (Crud usuario).Equivalente a registrar para nuestro caso.
    public boolean insertarDocente(Docente doc){  
        boolean respuesta = false;
        sSQLUsuario = "insert into usuario(nombres, apellidos,rol)" + 
                " values(?,?,?)";                
       
        sSQLDocente = "insert into docente(id_usuario,nombre_usDoc,passwd,tema_designado)" 
               + "values((select id_usuario from usuario order by id_usuario desc limit 1),?,?,?)";
                //+ "values((select id_usuario from usuario order by id_usuario desc limit 1),?,?)";
        try{
            PreparedStatement pstUsuario = cn.prepareStatement(sSQLUsuario);
            PreparedStatement pstDocente = cn.prepareStatement(sSQLDocente);
            
            //pstUsuario.setString(1, doc.getCodigoTema()); //estaba en este orden: 2,3,4,5
            pstUsuario.setString(1, doc.getNombres());      //Estaba en 2,3,4.
            pstUsuario.setString(2, doc.getApellidos());
            pstUsuario.setString(3, doc.getRol());
                         
            pstDocente.setString(1, doc.getNombre_usDoc());
            //Primero encriptamos el password y luego lo ingresamos a la base de datos.
            //String passwdEncriptado = DigestUtils.md5Hex(doc.getPassw_doc());                      
            pstDocente.setString(2,doc.getPassw_doc());
            pstDocente.setInt(3, doc.getTema_designado());
            ///Para saber si se añadio.
            int n = pstUsuario.executeUpdate();
            if(n != 0){                          
                    int p = pstDocente.executeUpdate();
                return p!=0;  
            }
            else{
                return false;
            }
                       
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
            //respuesta = false;
        } 
        return respuesta;
    }
    //Metodo leer datos  del usuario (Crud Usuario) y demas(falta).
     public boolean actualizarDatosDoc(Docente doc){
        boolean respuesta = false;         
        
        sSQLUsuario = "update usuario set nombres=?,apellidos=?"
                + "where id_usuario= ?";             //where id_usuario=? por defecto.            
    
        //  "Select id_usuario from docente where (nombre_usdoc = '"+ nombreUsDoc+"')";
        
        sSQLDocente = "update docente set nombre_usDoc=?,passwd=?"
                +"where id_usuario=?";              //where id_usuario=? por defecto.
        try {
            PreparedStatement pstUsuario = cn.prepareStatement(sSQLUsuario);
            PreparedStatement pstDocente = cn.prepareStatement(sSQLDocente);
            
            pstUsuario.setString(1, doc.getNombres());      
            pstUsuario.setString(2, doc.getApellidos());
            //pstUsuario.setInt(3,idUsuarioDoc); // ver este aributo, puede que sea la causa del registro inconsistente.
            pstUsuario.setInt(3,doc.getId_usuario());
            
            pstDocente.setString(1, doc.getNombre_usDoc());
            pstDocente.setString(2,doc.getPassw_doc());
            //pstDocente.setInt(3,idUsuarioDoc); // ver este aributo, puede que sea la causa del registro inconsistente.
            pstDocente.setInt(3,doc.getId_usuario());
            
            int n = pstUsuario.executeUpdate();
            if(n != 0){                          
                    int p = pstDocente.executeUpdate();
                return p!=0;  
            }
            else{
                return false;
            }
        }catch(SQLException e){
         JOptionPane.showMessageDialog(null, e);
        }
        return respuesta; 
     }  

    public void actualizarTemaDesignado(Docente d) {
        int idTemaDesigDoc = d.getTema_designado();               
        sSQLDocente = "update docente set tema_designado=?";
               
        try {            
            PreparedStatement pstDocente = cn.prepareStatement(sSQLDocente);        
            pstDocente.setInt(1, idTemaDesigDoc);            
            int n = pstDocente.executeUpdate(); 
            if(n != 0){                          
                    JOptionPane.showMessageDialog(null, "Se actualizo el registro");
            }
            else{
                    JOptionPane.showMessageDialog(null, "No se actualizo el registro");
            }
        }catch(SQLException e){
         JOptionPane.showMessageDialog(null, e);
        }
    }

    public DefaultTableModel mostrarDatosDocMat() {   //Puede que esta funcionalidad de errores por que mostramos todo
        DefaultTableModel modelo;                       //Aunque para esta parte es necesario mostrar todos los temas
        String[] titulos ={"cod_tema","nombres"};       //sin importar el docente que haya subiado algo...revisar por si
        String[] res = new String[2];                   //acaso.
        modelo= new DefaultTableModel(null,titulos);
        totalRegistros = 0;
         sSQLTema = "select t.cod_tema, u.nombres from tema t inner join usuario u "   
                + " on t.id_usuario = u.id_usuario  inner join docente d on u.id_usuario = d.id_usuario where d.tema_designado='1'"                   
                + "order by t.cod_tema";                                     
                             
         try{
            Statement statement=cn.createStatement();            
            ResultSet rs = statement.executeQuery(sSQLTema);            
            while(rs.next()){
                res[0]= rs.getString("cod_tema");                
                res[1]= rs.getString("nombres"); //Puede que de error aqui.
                modelo.addRow(res);
                totalRegistros = totalRegistros+1;                                  
            }
            return modelo;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        return modelo;
    }   

    public void ejecutar(String cdTema, String nbDoc) throws IOException {
        //byte[] b = null;
         
        sSQLMatDoc = "select t.formulas from tema t inner join usuario u "   //Probar con un 3º innerjoin mañana, falta t.conceptos
                + " on t.id_usuario = u.id_usuario  where u.nombres = '"+nbDoc+"' and t.cod_tema='" +cdTema+"'";                  
        try{
            Statement statement=cn.createStatement();            
            ResultSet rs = statement.executeQuery(sSQLMatDoc);            
            while(rs.next()){
                Blob blob=rs.getBlob("formulas");   //si falla probar con 1.
                InputStream is = blob.getBinaryStream();
                //LLamamos al metodo guardar imagen disco duro.
                guardarImagenDiscoDuro(is, cdTema); //Ver si se puede modificar esta parte("cdTema").                                                 
            }
            
        }catch(SQLException e){
            e.printStackTrace();
        }
        try {
            conexion.conexion().close();
        } catch (SQLException ex) {
            Logger.getLogger(ConexionDocente.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    public static void guardarImagenDiscoDuro(InputStream is, String cdTema) { // Si funciona mover este metodo a alguna clase o crearla en el paquete clases.
        String nomUs = lblnombreUsEst.getText();
        String carpeta = "C:\\Users\\G\\Documents\\NetBeansProjects\\SistemaTutorInteligenteIngeco\\Descargas\\"+nomUs;
        File carp = new File(carpeta);  // hasta aqui creamos carpeta.
        carp.mkdirs();
        File fichero= new File(carpeta + "\\"+cdTema+".png");  //cdTema por defecto, validar que tipo de imagen estamos guardando si es necesario como dice el video.
        BufferedInputStream in = new BufferedInputStream(is); //"jpg" por defecto en la parte de arriba
        try {
            BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(fichero));
            byte[] bytes = new byte[8096];
            int len = 0;
            while((len = in.read(bytes))>0){
                out.write(bytes,0,len);
                
            }                        
            out.flush();
            out.close();
            in.close();
            //Agregado por mi            
            JOptionPane.showMessageDialog(null, "Se descargo el archivo","Sistema Tutor Inteligente Ingeco", JOptionPane.INFORMATION_MESSAGE);
            //Fin agregado                 
                    
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }      
    }
    //Falta el codigo para guardar la imagen en alguna carpeta, ver mañana xD.  
    
    ////crud eliminar
    public boolean eliminar(Docente d){//probar mañana
        boolean res=false;  //por defecto asumimos que no se elimino el docente.
        sSQLDocente="delete from docente where id_usuario=?";
        sSQLUsuario="delete from usuario where id_usuario=?";
        try {            
            PreparedStatement pstDocente = cn.prepareStatement(sSQLDocente); 
            PreparedStatement pstUsuario = cn.prepareStatement(sSQLUsuario);
            pstDocente.setInt(1, d.getId_usuario());  //ver si esto provoca errores por usar a usuario en vez de doc.           
            pstUsuario.setInt(1,d.getId_usuario());
            
            int n = pstDocente.executeUpdate(); 
            int m = pstUsuario.executeUpdate(); 
            if(n != 0 && m!=0){                          
                    //JOptionPane.showMessageDialog(null, "Se elimino al docente");                    
                    res=true;
            }
            else{
                    JOptionPane.showMessageDialog(null, "No se elimino el docente");
                    
            }
        }catch(SQLException e){
         JOptionPane.showMessageDialog(null, e);
        }
        return res;
    
    }
 }
 



    
 
    

