/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conexion;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author Gonchy.
 */
public class ConexionDocente {
    
    Conexion conexion;
    Connection cn= conexion.conexion();

    public ConexionDocente() {
        conexion = new Conexion();
    }
    //Metodo insertar usuario (Crud usuario).Equivalente a registrar para nuestro caso.
    public String insertarDocente(String rol, String nombre_usuarioDoc, int passw_docente){
        String respuesta = null;
        try{
            Connection acceso = conexion.conexion();
            CallableStatement cs = acceso.prepareCall("(call sp_insertUsuario(?,?,?)");
            cs.setString(1, rol);
            cs.setString(2, nombre_usuarioDoc);
            cs.setInt(3, passw_docente);
           
            
            int numFilasAfectadas=cs.executeUpdate();
            if(numFilasAfectadas>0){
                respuesta = "Registro exitoso.";
            }
        }catch(SQLException e){
        
        } 
        return respuesta;
    }
    //Metodo leer datos  del usuario (Crud Usuario).
    
}
