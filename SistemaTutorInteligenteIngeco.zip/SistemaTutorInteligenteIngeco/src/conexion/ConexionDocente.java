/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conexion;

import clases.Docente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Gonchy.
 */
public class ConexionDocente {
    
    private Conexion conexion = new Conexion();;
    private Connection cn= conexion.conexion();
    private String sSQLDocente;
    private String sSQLUsuario;
    
    public ConexionDocente(){
    
    }
   
    //Metodo insertar usuario (Crud usuario).Equivalente a registrar para nuestro caso.
    public boolean insertarDocente(Docente doc){  
        boolean respuesta = false;
        sSQLUsuario = "insert into usuario(cod_tema,nombres, apellidos,rol)" + 
                " values(?,?,?,?)";               
       
        sSQLDocente = "insert into docente(id_usuario,nombreUsuarioDoc,passwd)" 
               + "values((select id_usuario from usuario order by id_usuario desc limit 1),?,?)";
                //+ "values((select id_usuario from usuario order by id_usuario desc limit 1),?,?)";
        try{
            PreparedStatement pstUsuario = cn.prepareStatement(sSQLUsuario);
            PreparedStatement pstDocente = cn.prepareStatement(sSQLDocente);
            
            pstUsuario.setString(2, doc.getCodigoTema());
            pstUsuario.setString(3, doc.getNombres());
            pstUsuario.setString(4, doc.getApellidos());
            pstUsuario.setString(5, doc.getRol());
                        
            pstDocente.setString(2, doc.getNombre_usDoc());
            pstDocente.setInt(3, doc.getPassw_doc());
            ///Para saber si se añadio.
            int n = pstUsuario.executeUpdate();
            if(n != 0){                          
                    int p = pstDocente.executeUpdate();
                return p!=0;  
            }
            else{
                return false;
            }
                       
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
            //respuesta = false;
        } 
        return respuesta;
    }
    //Metodo leer datos  del usuario (Crud Usuario).
    
}
