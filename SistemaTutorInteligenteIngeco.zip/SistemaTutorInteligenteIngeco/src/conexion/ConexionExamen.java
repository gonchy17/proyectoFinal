/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package conexion;

import clases.Docente;
import clases.Examen;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author G
 */
public class ConexionExamen {

    
    private Conexion conexion = new Conexion();
    private Connection cn= conexion.conexion();
    
    private String sSQLExamen;
    private String sSQLDocente; //talves borremos esto.
    
    private FileInputStream fis = null;
    private FileInputStream fis2 = null;
    
    public int totalRegistros;
    public ConexionExamen() {
    }
    
    //Crud examen
    public boolean insertarExamen(Examen examen) throws FileNotFoundException{
        boolean res = false;//
        //posiblemente añadir id_usuario docente para este caso o validar con una consulta, pero creo que
        //no hay relacion en esas tablas(examen-usuario), investigar despues...XD
        
        sSQLExamen = "insert into examen(cod_examen,cod_tema,id_tema,pregunta,id_usuario)"+  
                     " values(?,(select cod_tema from tema where cod_tema ='"+examen.getCod_tema()+"'"
                + "and id_tema='"+examen.getId_tema()+"'),"
                + "(select id_tema from tema where id_tema='"+examen.getId_tema()+"'),?,"
                + "(select id_usuario from docente where id_usuario='"+examen.getId_usuario()+"'))";
               // + "(select id_tema from tema order by id_tema desc limit 1),?)"; por defecto.
                //" values(?,(select cod_tema from tema order by cod_tema asc limit 1),?)"; //probar esto mañana             
              
        try{
            PreparedStatement pstExamen = cn.prepareStatement(sSQLExamen);                        
            //pstUsuario.setString(1, doc.getCodigoTema()); //estaba en este orden: 2,3,4,5
            //File file = new File(examen.getCod_examen());
            File pregunta = new File(examen.getPregunta());
            fis = new FileInputStream(pregunta);
           // File respuesta = new File(examen.getRespuesta());
            //fis2 = new FileInputStream(respuesta);
            
            pstExamen.setString(1, examen.getCod_examen()); 
            //pstExamen.setString(2, examen.getCod_tema());
            //pstTema.setBinaryStream(2,fis,(int)file.length());      //Estaba en 1,2,3
            pstExamen.setBinaryStream(2, fis,(int)pregunta.length());      //Ver si modificamos a longblob.2 por defct                                 
           // pstExamen.setBinaryStream(4, fis2,(int)respuesta.length());      // ver si es necesario  
            
            ///Para saber si se añadio.
            int n = pstExamen.executeUpdate();
            if(n != 0){                          
                res = true;
            }
            else{
                return false;
            }
                       
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
            //respuesta = false;
        } 
        return res;
    }
    
    public DefaultTableModel mostrar(String codEx, String id_user) throws IOException{  //cod_tema por defecto
        //tener cuidado con nombreExamen, puede ser tambien nombreTema, talvez modifiquemos algo de codigo en dicho form.
        //
        DefaultTableModel modelo;
        String[] datosDoc = new String[2]; //4 por defecto
        String[] titulos= {"cod_examen","cod_tema"};
        totalRegistros = 0;        
        // todo entonces descomentar datosdoc y agregat id_tema en la consulta..
        modelo = new DefaultTableModel(null, titulos);
        //aca deberia modificar la consulta con id_usuario,solo usaria un inner join mas       
        //1º consulta
        /*sSQLExamen = "select e.cod_examen, t.cod_tema, e.pregunta, e.respuesta from examen e inner join tema t"
                + "on e.cod_tema= t.cod_tema "
                + "where e.cod_examen like '%"+codEx+"%' and "
                + "t.id_usuario='%"+id_user+"%'";
        */        
        sSQLExamen = "select e.cod_examen, t.cod_tema, e.pregunta, e.respuesta from examen e inner join tema t"
                + " on e.id_tema = t.id_tema "
                + "where t.id_usuario ='"+id_user+"' and e.cod_examen like '%"+codEx+ "%'";
               // + "t.id_usuario='"+id_user+"'";
                
                  //debo mejorar el id tema
                             
         try{
            Statement statement=cn.createStatement();            
            ResultSet rs = statement.executeQuery(sSQLExamen);
            Blob imagen = null;
            while(rs.next()){
                datosDoc[0]= rs.getString("cod_examen");                
                datosDoc[1]= rs.getString("cod_tema"); //Puede que de error aqui.                        
                //datosDoc[2]= rs.getString("pregunta"); //quizas estos 2 ultimos borremos y talves uno de arriba.        
                //datosDoc[3]= rs.getString("respuesta");//solo es necesario mostrar nombres y no asi  
                totalRegistros = totalRegistros+1;
                modelo.addRow(datosDoc);                  
            }
            return modelo;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        return modelo;
    }
    

    public boolean insertarSolucion(Examen examen) throws FileNotFoundException {
        boolean res=false;  //por defecto no se inserto.
         sSQLExamen = "update examen set respuesta=? "
                 + "where cod_examen='"+examen.getCod_examen()+"'";                         
             
        try{
            PreparedStatement pstExamen = cn.prepareStatement(sSQLExamen);                        
            //pstUsuario.setString(1, doc.getCodigoTema()); //estaba en este orden: 2,3,4,5
            //File file = new File(examen.getCod_examen());
            File respuesta = new File(examen.getRespuesta());
            fis = new FileInputStream(respuesta);                                       
            pstExamen.setBinaryStream(1, fis,(int)respuesta.length());      //Ver si modificamos a longblob.2 por defct                                 
           // pstExamen.setBinaryStream(4, fis2,(int)respuesta.length());      // ver si es necesario             
            ///Para saber si se añadio.
            int n = pstExamen.executeUpdate();
            if(n != 0){                          
                res = true;
            }
            else{
                return false;
            }
                       
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
            //respuesta = false;
        } 
        return res;
        
    }

    public DefaultTableModel mostrarTemasExamenes(String tema, Docente d) {
        DefaultTableModel res;
        String[] datosDoc = new String[2]; 
        String[] titulos= {"cod_examen","cod_tema"};
        totalRegistros = 0;
        
        res = new DefaultTableModel(null, titulos); 
        //aparentemente funciuona..probar con otros usuarios.
        sSQLExamen = "select t.cod_tema, e.cod_examen from tema t inner join docente d "   
                + " on t.id_usuario = d.id_usuario  inner join examen e on t.cod_tema = e.cod_tema"
                + " where d.tema_designado='1' and t.cod_tema='"+tema+"' and d.id_usuario='"+d.getId_usuario()+"'"                   
                + "order by t.cod_tema";  
         /*
            "select e.cod_examen, t.cod_tema, e.pregunta, e.respuesta from examen e inner join tema t"
                + " on e.cod_tema = t.cod_tema where t.cod_tema='"+codTema+ "'" ;
        */                 
         try{
            Statement statement=cn.createStatement();            
            ResultSet rs = statement.executeQuery(sSQLExamen);            
            while(rs.next()){
                datosDoc[0]= rs.getString("cod_tema");                
                datosDoc[1]= rs.getString("cod_examen");                                    
                totalRegistros = totalRegistros+1;
                res.addRow(datosDoc);                  
            }
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, e);
        }
        return res;
    }
    
    public  boolean eliminar(Examen examen) {
         boolean res=false; // no se elimino por defecto
         //probar mañana, ver si es necesario usar el eliminar examen.
         
        sSQLExamen="delete from examen where cod_examen=?";
        try {            
            
            PreparedStatement pstExamen = cn.prepareStatement(sSQLExamen);                                 
            pstExamen.setString(1, examen.getCod_examen());
            
            int n = pstExamen.executeUpdate(); 
            
            if(n != 0 ){                          
                                   
               JOptionPane.showMessageDialog(null, "Se elimino el examen",
                       "Sistema Tutor Inteligente Ingeco",JOptionPane.INFORMATION_MESSAGE);
                res=true;
            }
            else{
                    res=false;
                    
            }
        }catch(SQLException e){
         JOptionPane.showMessageDialog(null, e);
        }
         return res;
    }

    public String obtenerId_tema(String id_user, String cod_tema) {
        String res = null; //ojo, aca uso tema y no examen, si es necesario mover este metodo a conexion tema.
        sSQLExamen="select id_tema from tema where id_usuario='"+id_user+"' and cod_tema='"+cod_tema+"' ";
        try {            
            Statement statement=cn.createStatement();            
            ResultSet rs = statement.executeQuery(sSQLExamen); 
            if(rs.next()){
                res=rs.getString("id_tema");
                
            }                                                              
            
        }catch(SQLException e){
         JOptionPane.showMessageDialog(null, e);
        }
        return res;
    }
}
/*
    al hacer los registrps de examen y tema no se muestran en el primer intento, tengo que volver a entrar al sistema para
    poder ver los registros...revisar al final de la implementacion.
   se esta trabajando con sistemaingeco5 y se elimino el mostrar() del frmExamen por inconsistencia.
*/